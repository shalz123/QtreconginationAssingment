package qtrecongition;

import java.io.IOException;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.Color;
import org.testng.Assert;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;



import org.testng.annotations.Test;

import pageObjects.Qt_verify_login;
import resources.base;

public class qt111 extends base
{
	

 public static Logger log =LogManager.getLogger(base.class.getName());
	@Test
	public void qtframework() throws IOException, InterruptedException
	{
		driver=initializeDriver();
		driver.manage().window().maximize();

		driver.get(prop.getProperty("url"));
		
		Qt_verify_login qt=new Qt_verify_login (driver);
	    qt.username().sendKeys("shalini.js@qualitestgroup.com");
	    qt.password().sendKeys("P@ssw0rd");
	    qt.login().click();
	    log.info("user  has sucessfully logined");
	    qt.title(); 
	 
	   
	}
	
	}
	

