package qtrecongition;

import java.io.IOException;

import org.openqa.selenium.Keys;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import pageObjects.Qt_sendkudos;
import pageObjects.Qt_verify_login;
import resources.base;

public class qt31 extends base
{
	@BeforeTest
	public void login() throws IOException
	{
			driver=initializeDriver();
			driver.manage().window().maximize();

			driver.get(prop.getProperty("url"));
			
			Qt_verify_login qt=new Qt_verify_login (driver);
		    qt.username().sendKeys("shalini.js@qualitestgroup.com");
		    qt.password().sendKeys("P@ssw0rd"); 
		    qt.login().click();
	   
	}

@Test
public void sendkudos() throws InterruptedException
{
	Qt_sendkudos k= new Qt_sendkudos(driver);
	//user should be able to send kudos from actvity page
	k.sendk().click();
	k.enteremail().sendKeys("Akash M  (akash.m@qualitestgroup.com)" + Keys.DOWN);
	k.click1().click();
	k.comm().sendKeys("goood" );
	k.snd().click();
	Thread.sleep(3000);
	k.cancl().click();	
	
}

	
@AfterTest
public void sendkudos2() throws InterruptedException
{
	Qt_sendkudos n= new Qt_sendkudos(driver);
	Thread.sleep(2000);
	n.resendbtn().click();
	n.click1().click();
	n.comm().sendKeys("tests");
	n.snd().click();
	
}





}
