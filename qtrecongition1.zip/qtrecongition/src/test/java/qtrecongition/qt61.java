package qtrecongition;

import java.io.IOException;

import org.openqa.selenium.Keys;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import pageObjects.Qt_others;
import pageObjects.Qt_verify_login;
import resources.base;

public class qt61 extends base
{

	 public static Logger log =LogManager.getLogger(base.class.getName());
	@BeforeTest
	public void login() throws IOException
	{
			driver=initializeDriver();
			driver.manage().window().maximize();

			driver.get(prop.getProperty("url"));
			
			Qt_verify_login qt=new Qt_verify_login (driver);
		    qt.username().sendKeys("shalini.js@qualitestgroup.com");
		    qt.password().sendKeys("P@ssw0rd"); 
		    qt.login().click();
	   
	}
	
	@Test
	public void kudosfromme() throws InterruptedException
	{
		 Qt_others kf=new  Qt_others(driver);
		 Thread.sleep(400);
		 kf. kudofromme().click();
		 Assert.assertTrue(kf.kudofromme().isDisplayed());
	
        
		
	}
	
    @Test
    public void kudostome() throws InterruptedException
    {
    	 Qt_others t=new  Qt_others(driver);
    	 Thread.sleep(4000);
    	 t.Kudotome().click();
    	 
    	 Assert.assertTrue(t.Kudotome().isDisplayed());
    }
    
    
    
	@Test
	public void Zactivity() throws InterruptedException
	{
		 Qt_others a=new  Qt_others(driver);
		 Thread.sleep(4000);
		 a.activity().click();
	     String a1=a.Kudocnt1().getText();
	     System.out.println(a1);
		    Thread.sleep(2000);
		    a.sendk().click();
		    Thread.sleep(2000);
			a.enteremail().sendKeys("Akash M  (akash.m@qualitestgroup.com)" + Keys.DOWN);
			a.click1().click();
			a.comm().sendKeys("goood" );
			a.snd().click();
			Thread.sleep(2000);
			a.cancl().click();
			Thread.sleep(2000);
		    a.Kudotome().click();
		    a.kudofromme().click();
		    a.activity().click();
		   driver.navigate().refresh();
		   a.activity().click();
		    String a2=a.Kudocnt1().getText();
		     System.out.println(a2);
		    
		    
	
		 
	}
}
