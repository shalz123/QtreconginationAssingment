package qtrecongition;

import java.io.IOException;

import org.openqa.selenium.Keys;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import pageObjects.Qt_kudossearch;
import pageObjects.Qt_verify_login;
import resources.base;

public class qt41 extends base
{
	 public static Logger log =LogManager.getLogger(base.class.getName());
	@BeforeTest
	public void login() throws IOException
	{
			driver=initializeDriver();
			driver.manage().window().maximize();
			driver.get(prop.getProperty("url"));
			
			Qt_verify_login qt=new Qt_verify_login (driver);
		    qt.username().sendKeys("shalini.js@qualitestgroup.com");
		    qt.password().sendKeys("P@ssw0rd"); 
		    qt.login().click();
	        
	}
   @Test
   public void kudosearch1()
   {
	   Qt_kudossearch s= new Qt_kudossearch(driver);
	   
	  Assert.assertTrue(s.searchkudo().isDisplayed());
	  log.info("kudo search is displayed"); 
   }
   
   @Test
   public void kudosearch2() throws InterruptedException
   {
	   Qt_kudossearch s1= new Qt_kudossearch(driver);
	   Thread.sleep(2000);
	   s1.searchkudo().click();
	   Thread.sleep(2000);
	   s1.searchoption().sendKeys("Akash M  (akash.m@qualitestgroup.com)" + Keys.DOWN);
	   Thread.sleep(2000);
	   s1.searchbutton().click();
	   Thread.sleep(2000);
	   Assert.assertEquals(s1.postsearch().getText(), "Akash M");
	   log.info("akash name is displayed"); 
	   
   }
  
   
}
