package qtrecongition;

import java.io.IOException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.Keys;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import pageObjects.Qt_others;
import pageObjects.Qt_verify_login;
import resources.base;

public class qt62  extends base
{
	public static Logger log =LogManager.getLogger(base.class.getName());
	@BeforeTest
	public void login() throws IOException
	{
			driver=initializeDriver();
			driver.manage().window().maximize();

			driver.get(prop.getProperty("url"));
			
			Qt_verify_login qt=new Qt_verify_login (driver);
		    qt.username().sendKeys("shalini.js@qualitestgroup.com");
		    qt.password().sendKeys("P@ssw0rd"); 
		    qt.login().click();
		    
	   
	}
	 
	@Test 
	public void kudohimself() throws InterruptedException
	{
		 Qt_others v=new  Qt_others(driver);
		  v.sendk().click();
		    Thread.sleep(2000);
			v.enteremail().sendKeys("Shalini J S  (shalini.js@qualitestgroup.com)" + Keys.DOWN);
			v.click1().click();
			v.comm().sendKeys("goood" );
			v.snd().click();
			Thread.sleep(2000);
			v.cancl().click();
			Thread.sleep(2000);
			String z1=v.fromname().getText();
			System.out.println(z1);
			Thread.sleep(2000);
			v.activity().click();
			Thread.sleep(2000);
			String z2=v.toname().getText();
			System.out.println(z2);
			Thread.sleep(4000);
		    Assert.assertEquals(z1, z2);
		   log.error("fail:user cannot be send kudo himself");
		   
	}
	
	
}
