package qtrecongition;
import java.io.IOException;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.Color;
import org.testng.Assert;
import org.testng.annotations.Test;

import pageObjects.Qt_verify_login;
import resources.base;
public class q12 extends base
{
	@Test
	public void colors() throws IOException, InterruptedException
	{
		
	
	driver=initializeDriver();
	driver.manage().window().maximize();

	driver.get(prop.getProperty("url"));
	
	Qt_verify_login a=new Qt_verify_login (driver);
	WebElement TB = a.upperb();
	String G=TB.getCssValue("background-color");
    String gold=Color.fromString(G).asHex();
    Assert.assertEquals( "#fdcc16",gold);
    System.out.println("gold"); 

	WebElement LB = a.lowb();	
	String W=LB.getCssValue("background-color");
	 String White=Color.fromString(W).asHex();
	Assert.assertEquals( "#ffffff",White);
	System.out.println("White");
	 
	WebElement Log = a.lb();
	String N=Log.getCssValue("background-color");
	 String Navy=Color.fromString(N).asHex();
	Assert.assertEquals("#2a2559",Navy);
	System.out.println("Navy");
	
	}
}
