package qtrecongition;

import java.io.IOException;

import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import pageObjects.Qt_activity;
import pageObjects.Qt_verify_login;
import resources.base;




public class qt21 extends base
{
	public static Logger log =LogManager.getLogger(base.class.getName());
	@BeforeTest
public void login() throws IOException, InterruptedException
{
		driver=initializeDriver();
		driver.manage().window().maximize();

		driver.get(prop.getProperty("url"));
		
		Qt_verify_login qt=new Qt_verify_login (driver);
	    qt.username().sendKeys("shalini.js@qualitestgroup.com");
	    qt.password().sendKeys("P@ssw0rd");
	    qt.login().click();
	 
	 

   
}
	@Test
	public void qtactivity() 
	{
		 Qt_activity  qa=new  Qt_activity (driver);
		 System.out.println(qa.returnNameLeft());
		 qa.title();
		 log.info("title has displayed");
    }
	

	
}
