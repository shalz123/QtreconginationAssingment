package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import resources.base;

public class Qt_verify_login extends base
{
	public WebDriver driver;
	By username=By.xpath("//body/div[2]/form[1]/input[1]");
	By password=By.xpath("//body/div[2]/form[1]/input[2]");
	By login=By.xpath("//button[contains(text(),'Login')]");
	By upper = By.xpath("//body/div[1]");
	By lower = By.xpath("//body");
	By loginb=By.xpath("//button[contains(text(),'Login')]");
	
	//1.1.1 User should be allowed login using username and password

	public Qt_verify_login(WebDriver driver)
	{
		this.driver=driver;
	}

	public WebElement username()
	{
		return driver.findElement(username);
		
	}
	
	public WebElement password()
	{
		return driver.findElement(password);
	}
	public WebElement login()
	{
		return driver.findElement(login);
	}
	public WebElement upperb() 
	{
		return driver.findElement(upper);
	}
	
	public WebElement lowb() 
	{
		return driver.findElement(lower);
	}
	
	public WebElement lb() 
	{
		return driver.findElement(loginb);
	}
	//Application title should be displayed as “QTRecognition”
	public  void title()
	{
		System.out.println(driver.getTitle());
	}
	
	
}
