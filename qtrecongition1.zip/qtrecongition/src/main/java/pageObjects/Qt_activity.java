package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import resources.base;

public class Qt_activity extends base
{
	public WebDriver driver;
	
	By name_left = By.xpath("//body/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/h5[1]");

	public Qt_activity(WebDriver driver)
	{
		this.driver=driver;
	}
	public boolean returnNameLeft()
	{
		return driver.findElement(name_left).isDisplayed();
	}
	public  void title()
	{
		System.out.println(driver.getTitle());
	}
	
}
